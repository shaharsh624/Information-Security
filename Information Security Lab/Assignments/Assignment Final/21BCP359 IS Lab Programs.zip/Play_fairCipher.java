import java.util.Scanner;

public class Play_fairCipher {
    public static void main(String[] args) {
        System.out.println("PlayFair Cipher!!");

        boolean stop = false;
        char[][] keyArray = new char[5][5];
        boolean[] isPresent = new boolean[26];
        String key;

        Scanner scanner = new Scanner(System.in);

        while (!stop) {
            System.out.println("\n1. Encryption");
            System.out.println("2. Decryption");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("Enter the key: ");
                key = scanner.next().toLowerCase();

                int count = 0;
                for (int i = 0; i < 26; i++) {
                    isPresent[i] = false;
                }

                // Forming keyArray 5x5
                for (int i = 0; i < 5; i++) {
                    for (int j = 0; j < 5; j++) {
                        if (count != key.length()) {
                            if (key.charAt(count) == 'j') {
                                keyArray[i][j] = 'i';
                            } else if (!isPresent[key.charAt(count) - 97]) {
                                keyArray[i][j] = key.charAt(count);
                                isPresent[key.charAt(count) - 97] = true;
                            } else {
                                j--;
                            }
                            count++;
                        } else {
                            for (int k = 0; k < 26; k++) {
                                if (k + 97 != 'j') {
                                    if (!isPresent[k]) {
                                        keyArray[i][j] = (char) (k + 97);
                                        isPresent[k] = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                // Display keyArray
                System.out.println("\nKey Array 5x5:");
                for (int i = 0; i < 5; i++) {
                    for (int j = 0; j < 5; j++) {
                        System.out.print(keyArray[i][j] + " ");
                    }
                    System.out.println();
                }
            }

            if (choice == 1) {
                // Encryption
                String plainText;
                String cipherText = "";

                System.out.print("Enter the plain text: ");
                scanner.nextLine(); // Consume the newline character
                plainText = scanner.nextLine().toLowerCase();

                plainText = plainText.replaceAll("j", "i");
                if (plainText.length() % 2 != 0) {
                    plainText += "z";
                }

                int c = 0;
                while (c < plainText.length()) {
                    int ix1 = 0, iy1 = 0, ix2 = 0, iy2 = 0;
                    int f1 = 0, f2 = 0;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 5; j++) {
                            if (plainText.charAt(c) == keyArray[i][j]) {
                                ix1 = i;
                                iy1 = j;
                                f1 = 1;
                                if (f2 == 1) {
                                    j = 5;
                                    i = 5;
                                }
                            }
                            if (plainText.charAt(c + 1) == keyArray[i][j]) {
                                ix2 = i;
                                iy2 = j;
                                f2 = 1;
                                if (f1 == 1) {
                                    j = 5;
                                    i = 5;
                                }
                            }
                        }
                    }

                    if (f1 == 1 && f2 == 1) {
                        if (ix1 == ix2) {
                            cipherText += keyArray[ix1][(iy1 + 1) % 5];
                            cipherText += keyArray[ix1][(iy2 + 1) % 5];
                        } else if (iy1 == iy2) {
                            cipherText += keyArray[(ix1 + 1) % 5][iy1];
                            cipherText += keyArray[(ix2 + 1) % 5][iy2];
                        } else {
                            cipherText += keyArray[ix1][iy2];
                            cipherText += keyArray[ix2][iy1];
                        }
                        c += 2;
                        f1 = 0;
                        f2 = 0;
                        ix1 = 0;
                        ix2 = 0;
                        iy1 = 0;
                        iy2 = 0;
                    }
                }

                System.out.println("\nCipher Text: " + cipherText);
            } else if (choice == 2) {
                // Decryption
                String plainText = "";
                String cipherText;

                System.out.print("Enter the Cipher Text: ");
                cipherText = scanner.next().toLowerCase();

                int c = 0;
                while (c < cipherText.length()) {
                    int ix1 = 0, iy1 = 0, ix2 = 0, iy2 = 0;
                    int f1 = 0, f2 = 0;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 5; j++) {
                            if (cipherText.charAt(c) == keyArray[i][j]) {
                                ix1 = i;
                                iy1 = j;
                                f1 = 1;
                                if (f2 == 1) {
                                    j = 5;
                                    i = 5;
                                }
                            }
                            if (cipherText.charAt(c + 1) == keyArray[i][j]) {
                                ix2 = i;
                                iy2 = j;
                                f2 = 1;
                                if (f1 == 1) {
                                    j = 5;
                                    i = 5;
                                }
                            }
                        }
                    }

                    if (f1 == 1 && f2 == 1) {
                        if (ix1 == ix2) {
                            plainText += keyArray[ix1][(iy1 - 1 + 5) % 5];
                            plainText += keyArray[ix1][(iy2 - 1 + 5) % 5];
                        } else if (iy1 == iy2) {
                            plainText += keyArray[(ix1 - 1 + 5) % 5][iy1];
                            plainText += keyArray[(ix2 - 1 + 5) % 5][iy2];
                        } else {
                            plainText += keyArray[ix1][iy2];
                            plainText += keyArray[ix2][iy1];
                        }
                        c += 2;
                        f1 = 0;
                        f2 = 0;
                        ix1 = 0;
                        ix2 = 0;
                        iy1 = 0;
                        iy2 = 0;
                    }
                }

                System.out.println("Plain Text: " + plainText);
            } else if (choice == 3) {
                stop = true;
            } else {
                System.out.println("\nInvalid input!");
            }
        }

        scanner.close();
    }
}
