public class BruteForce_2 {
    public static void main(String[] args) {
        for (int i = 65; i < 91; i++) {
            for (int j = 65; j < 91; j++) {
                for (int k = 65; k < 91; k++) {
                    String a = "" + (char) i + (char) j + (char) k;
                    System.out.println(a);
                }
            }
        }
    }
}
