import java.util.Scanner;

public class caesarCipher {
    public static void main(String[] args) {
        boolean stop = false;
        int choice;
        System.out.println("Caesar Cipher!\n");

        Scanner scanner = new Scanner(System.in);
        while (!stop) {
            System.out.println("1. Encryption");
            System.out.println("2. Decryption");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                // Encryption
                int key;
                System.out.print("Enter the key: ");
                key = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                String plainText;
                System.out.print("Enter the plain Text: ");
                plainText = scanner.nextLine();

                StringBuilder encryptedText = new StringBuilder();
                for (int j = 0; j < plainText.length(); j++) {
                    char currentChar = plainText.charAt(j);

                    if (currentChar != ' ') {
                        char encryptedChar;
                        if ((int) currentChar > 90) {
                            encryptedChar = (char) (((int) currentChar - 97 + key) % 26 + 97);
                        } else {
                            encryptedChar = (char) (((int) currentChar - 65 + key) % 26 + 65);
                        }
                        encryptedText.append(encryptedChar);
                    } else {
                        encryptedText.append(currentChar);
                    }
                }
                System.out.println("Encrypted Text: " + encryptedText);
            } else if (choice == 2) {
                // Decryption
                int key;
                System.out.print("Enter the key: ");
                key = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                String cipherText;
                System.out.print("Enter the Cipher text: ");
                cipherText = scanner.nextLine();

                StringBuilder decryptedText = new StringBuilder();
                for (int j = 0; j < cipherText.length(); j++) {
                    char currentChar = cipherText.charAt(j);

                    if (currentChar != ' ') {
                        char decryptedChar;
                        if ((int) currentChar > 90) {
                            decryptedChar = (char) (((int) currentChar - 97 - key + 26) % 26 + 97);
                        } else {
                            decryptedChar = (char) (((int) currentChar - 65 - key + 26) % 26 + 65);
                        }
                        decryptedText.append(decryptedChar);
                    } else {
                        decryptedText.append(currentChar);
                    }
                }
                System.out.println("Decrypted Text: " + decryptedText);
            } else if (choice == 3) {
                stop = true;
            } else {
                System.out.println("\nInvalid Choice!");
            }
        }
        scanner.close();
    }
}
