from cryptography.fernet import Fernet


key_generate=Fernet.generate_key()

key_addtion_var=Fernet(key_generate)


# plaintext="hello:"

pt = input("Enter your plain text: ")

cipher_text=key_addtion_var.encrypt(pt.encode())


for i in range(3):
    print()
print('encrypted text:',cipher_text )



for i in range(3):
    print()

decrypyted_text=key_addtion_var.decrypt(cipher_text.decode())
print("decrypted msg:", decrypyted_text)

for i in range(3):
    print()