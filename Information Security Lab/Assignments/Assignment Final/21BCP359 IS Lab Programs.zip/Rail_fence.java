import java.util.Scanner;

class Rail_fence {
    public static String encrypt(String plaintext, int key) {
        char[][] matrix = new char[key][plaintext.length()];
        int row = 0;
        int step = 1;

        for (int i = 0; i < plaintext.length(); i++) {
            matrix[row][i] = plaintext.charAt(i);
            row += step;

            if (row == 0 || row == key - 1) {
                step = -step;
            }
        }

        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < plaintext.length(); j++) {
                if (matrix[i][j] != 0) {
                    ciphertext.append(matrix[i][j]);
                }
            }
        }

        return ciphertext.toString();
    }

    public static String decrypt(String ciphertext, int key) {
        char[][] matrix = new char[key][ciphertext.length()];
        int row = 0;
        int step = 1;

        for (int i = 0; i < ciphertext.length(); i++) {
            matrix[row][i] = '*'; 
            row += step;

            if (row == 0 || row == key - 1) {
                step = -step;
            }
        }

        int index = 0;
        for (int i = 0; i < key; i++) {
            for (int j = 0; j < ciphertext.length(); j++) {
                if (matrix[i][j] == '*' && index < ciphertext.length()) {
                    matrix[i][j] = ciphertext.charAt(index++);
                }
            }
        }

        StringBuilder plaintext = new StringBuilder();
        row = 0;
        step = 1;

        for (int i = 0; i < ciphertext.length(); i++) {
            plaintext.append(matrix[row][i]);
            row += step;

            if (row == 0 || row == key - 1) {
                step = -step;
            }
        }

        return plaintext.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Encryption Key: ");
        int key = sc.nextInt();
        sc.nextLine(); 

        System.out.println("Enter Input String: ");
        String input = sc.nextLine();

        String encryptedText = encrypt(input, key);
        System.out.println("Encrypted Text: " + encryptedText);

        String decryptedText = decrypt(encryptedText, key);
        System.out.println("Decrypted Text: " + decryptedText);
    }
}
