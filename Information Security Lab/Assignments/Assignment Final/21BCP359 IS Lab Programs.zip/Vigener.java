public class Vigener {
    public static String encrypt(String plaintext, String key) {
        StringBuilder ciphertext = new StringBuilder();
        int keyLength = key.length();

        for (int i = 0; i < plaintext.length(); i++) {
            char plainChar = plaintext.charAt(i);
            char keyChar = key.charAt(i % keyLength);

            if (Character.isUpperCase(plainChar)) {
                int encryptedChar = 'A' + (plainChar - 'A' + keyChar - 'A') % 26;
                ciphertext.append((char) encryptedChar);
            } else if (Character.isLowerCase(plainChar)) {
                int encryptedChar = 'a' + (plainChar - 'a' + keyChar - 'a') % 26;
                ciphertext.append((char) encryptedChar);
            } else {
                // If the character is not a letter, leave it unchanged
                ciphertext.append(plainChar);
            }
        }

        return ciphertext.toString();
    }

    public static String decrypt(String ciphertext, String key) {
        StringBuilder plaintext = new StringBuilder();
        int keyLength = key.length();

        for (int i = 0; i < ciphertext.length(); i++) {
            char cipherChar = ciphertext.charAt(i);
            char keyChar = key.charAt(i % keyLength);

            if (Character.isUpperCase(cipherChar)) {
                int decryptedChar = 'A' + (cipherChar - 'A' - keyChar + 'A' + 26) % 26;
                plaintext.append((char) decryptedChar);
            } else if (Character.isLowerCase(cipherChar)) {
                int decryptedChar = 'a' + (cipherChar - 'a' - keyChar + 'a' + 26) % 26;
                plaintext.append((char) decryptedChar);
            } else {
                // If the character is not a letter, leave it unchanged
                plaintext.append(cipherChar);
            }
        }

        return plaintext.toString();
    }

    public static void main(String[] args) {
        String plaintext = "Hello, Vigenere!";
        String key = "KEY";

        String encryptedText = encrypt(plaintext, key);
        System.out.println("Encrypted Text: " + encryptedText);

        String decryptedText = decrypt(encryptedText, key);
        System.out.println("Decrypted Text: " + decryptedText);
    }
}
