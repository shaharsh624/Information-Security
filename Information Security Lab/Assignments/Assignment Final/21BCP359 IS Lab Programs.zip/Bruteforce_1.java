import java.util.Scanner;

public class Bruteforce_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the cipher text:");
        String cipherText = scanner.nextLine();

        for (int i = 1; i < 26; i++) {
            System.out.print("Key: -" + i + "/+" + (26 - i) + ") ");
            
            for (int j = 0; j < cipherText.length(); j++) {
                char currentChar = cipherText.charAt(j);

                if (currentChar != ' ') {
                    char decryptedChar;
                    if ((int) currentChar > 90) {
                        decryptedChar = (char) (((int) currentChar - 97 + i) % 26 + 97);
                    } else {
                        decryptedChar = (char) (((int) currentChar - 65 + i) % 26 + 65);
                    }
                    System.out.print(decryptedChar);
                } else {
                    System.out.print(currentChar);
                }
            }

            System.out.println();
        }

        scanner.close();
    }
}
